<?php
require "../../koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
</head>

<style>
    .main {
        height: 100vh;
    }

    .login-box {
        width: 500px;
        height: 300px;
        border-radius: 8px;
    }
</style>

<body>
    <div class="main d-flex justify-content-center align-items-center">
        <div class="login-box p-5 shadow">
            <form action="post-login.php" method="post">
                <div>
                    <label for="username">Username</label>
                    <input type="text" class="form-control" name="username" id="username">
                </div>
                <div>
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password">
                </div>
                <div>
                    <button class="btn btn-success form-control mt-3" type="submit" name="login">Login</button>
                </div>
                <div id="alert-container" class="mt-2">
                    <?php
                    if (isset($_GET['message'])) {
                        $code = $_GET['message'];
                        switch ($code) {
                            case 'credential_error':
                                $message = 'Username atau password yang kamu gunakan salah';
                                break;
                            case 'user_not_found':
                                $message = 'User tidak ditemukan';
                                break;
                        }
                        if (isset($message)) {
                            echo "<div class='alert alert-danger' role='alert'>$message</div>";
                        }
                    }
                    ?>
                </div>
            </form>
        </div>
    </div>


    <script src="login.js"></script>
    <script src="../../bootstrap/js/bootstrap.min.js"></script>
</body>

</html>